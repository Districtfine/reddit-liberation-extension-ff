# reddit-liberation-extension
 A Chrome Extension for reddit users to minimize lost productivity on reddit. Current Users: 40+
 
 Download on Chrome Webstore: https://chrome.google.com/webstore/detail/reddit-liberation-feed-bl/fllfmdjhnhhjokhdifhcdbpbfajfnhon
 
 Features:
 - blocks infinite feeds
 - custom content filters (whitelist and blacklist)

I am open to changing and improving the app, so please give feedback
